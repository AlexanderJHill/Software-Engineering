#ifndef _RANDOM_GENERATOR
#define _RANDOM_GENERATOR

#include <vector>
using namespace std;

vector<int> generateRandomNumber(int lowerBound, int upperBound, int length);

#endif