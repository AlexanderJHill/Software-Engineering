## Rutgers University Software Engineering Project
## Group 12
## 

How to use:

Run 'CrowdAnalysys.exe' in the Fisher Sim (standalone version) folder.
If any error messages appear, install the C++ redistributables
'vcredist_x64.exe' in the same folder, restart your machine and
try again. The standalone version runs only on Windows.

The code can be built using Qt Creator.
 Qt can be downloaded from https://www.qt.io/download-open-source/. You also need a suitable compiler already on your system.

Open 'FisherSim.pro', then build and run the project.


