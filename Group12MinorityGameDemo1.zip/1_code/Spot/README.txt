Spot Unit Test
Open the terminal
Be sure spot.cpp/.h and unit_spot_test.cpp are in the same directory
Compile cpp files: spot.cpp unit_spot_test.cpp
Run the files
This test should print output data to check if functions in the class works.
The printed output data are:
maximum capacity (maxcapacity)
number of agents (numAgents)
Spot crowd percent (%)

