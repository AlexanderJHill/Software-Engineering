Spot Unit Test-----------------------------------------------

Open the terminal
Be sure spot.cpp/.h and unit_spot_test.cpp are in the same directory
Compile cpp files: spot.cpp unit_spot_test.cpp
Run the files
This test should print output data to check if functions in the class works.
The printed output data are:
maximum capacity (maxcapacity)
number of agents (numAgents)
Spot crowd percent (%)



Agent Unit Test----------------------------------------------
**********Running unit test on Ubuntu 14.04**********

*Agent Unit Test
1. Open the terminal
2. Change directory: 
   cd $HOME/Demo1/2_unit_testing/Agent
3. Compile cpp files
   g++ -std=c++11 agent.cpp strategy.cpp randomgenerator.cpp unit_test_agent.cpp
4. Run
   ./a.out

*Strategy Unit Test
1. Assume that you are still in the same directory
2. Compile cpp files
   g++ -std=c++11 agent.cpp strategy.cpp randomgenerator.cpp unit_test_.cpp
3. Run
   ./a.out

**********Running unit test on Windows**********

*Agent Unit Test
1. Open a Developer Command Prompt as administartor
2. Change directory:
   cd $HOME\Demo1\2_unit_testing\Agent
3. Compile cpp files
   cl unit_test_agent.cpp agent.cpp strategy.cpp randomgenerator.cpp
4. Run
   unit_test_agent

*Strategy Unit Test
1. Assume that you are still in the same directory
2. Compile cpp files
   cl unit_test_strategy.cpp agent.cpp strategy.cpp randomgenerator.cpp
3. Run
   unit_test_strategy
   

