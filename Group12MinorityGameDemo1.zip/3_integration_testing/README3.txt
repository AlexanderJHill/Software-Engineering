Since the code is not yet combined into the GUI,
there are currently two types of integeration testing:
1. GUI integration
2. Code integration
For GUI integartion information go to GUI_Tests.txt
For code integration information go to Code_tests.txt
